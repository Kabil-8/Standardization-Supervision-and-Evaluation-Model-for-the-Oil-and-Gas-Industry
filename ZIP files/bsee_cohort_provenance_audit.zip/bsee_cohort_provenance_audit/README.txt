This package is an evidence audit, not a model rerun. It does not infer undocumented exclusion causes.
Rows marked reason_unrecoverable require the original preprocessing ledger or source-code-level reconstruction.
Feature timing remains unverified until dated BSEE releases/effective-date metadata are supplied.
