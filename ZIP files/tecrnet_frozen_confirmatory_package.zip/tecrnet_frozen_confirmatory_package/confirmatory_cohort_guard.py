"""Guard executed before any future confirmatory scoring."""
from pathlib import Path
import json
import pandas as pd

MINIMUM_CONFIRMATORY_TARGET_YEAR = 2026
PROHIBITED_FEATURE_YEAR_START = 2022
PROHIBITED_FEATURE_YEAR_END = 2024

def validate_unseen_cohort(index_csv):
    frame = pd.read_csv(index_csv)
    required = {"platform_id", "feature_year", "target_year"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    target_year = pd.to_numeric(frame["target_year"], errors="raise").astype(int)
    feature_year = pd.to_numeric(frame["feature_year"], errors="raise").astype(int)
    if (target_year < MINIMUM_CONFIRMATORY_TARGET_YEAR).any():
        raise RuntimeError(
            "Cohort includes target years that are not eligible for the frozen "
            "confirmatory analysis."
        )
    inspected = feature_year.between(
        PROHIBITED_FEATURE_YEAR_START, PROHIBITED_FEATURE_YEAR_END
    )
    if inspected.any():
        raise RuntimeError("Cohort overlaps previously inspected feature years.")
    if frame.duplicated(["platform_id", "feature_year"]).any():
        raise RuntimeError("Duplicate platform-feature-year rows detected.")
    return {
        "rows": int(len(frame)),
        "platforms": int(frame["platform_id"].nunique()),
        "target_year_min": int(target_year.min()),
        "target_year_max": int(target_year.max()),
        "status": "ELIGIBLE_BY_YEAR; confirm first-access provenance separately",
    }

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("index_csv", type=Path)
    args = parser.parse_args()
    print(json.dumps(validate_unseen_cohort(args.index_csv), indent=2))
