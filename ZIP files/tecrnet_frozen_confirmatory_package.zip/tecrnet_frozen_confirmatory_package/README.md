# Frozen TECR-Net confirmatory package

Freeze timestamp: 2026-10-15T04:18:01.404647+00:00

This directory contains 53 frozen model/evidence artifacts plus
a protocol, hashes and a future-cohort eligibility guard.

## Status

- 2014--2019: model fitting.
- 2020--2021: development, including tuning, early stopping, calibration,
  threshold selection, ablation and apparent performance estimation.
- 2022--2024: previously inspected and exploratory; not confirmatory.
- Confirmatory evaluation: pending a genuinely unseen future or external cohort.

## Before future scoring

1. Record the external/future data release and first-access timestamps.
2. Run `confirmatory_cohort_guard.py` before loading outcome labels into any
   analysis workflow.
3. Verify this directory using `freeze_manifest.sha256`.
4. Apply the frozen preprocessing, model ensemble, calibration and threshold
   exactly once.
5. Report all prespecified metrics and exclusions.

The hashes demonstrate that the files have not changed after freezing; they do
not by themselves prove that a future dataset was unseen. First-access records,
release dates and a timestamped registration provide that evidence.
