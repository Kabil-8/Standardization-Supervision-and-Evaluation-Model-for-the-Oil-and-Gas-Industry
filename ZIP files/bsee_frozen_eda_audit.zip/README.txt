BSEE FROZEN-PROTOCOL EDA AND LEAKAGE AUDIT
===============================================

Purpose
-------
Descriptive analysis for the locked TECR-Net study. No model is trained or selected.
Target: recorded INC in t+1 from consecutive platform years t-2,t-1,t.

Complete panel
--------------
Rows: 141,730
Platforms: 6,158
Coverage: 1947-2025

Exact sequence cohort
---------------------
     split  year_start  year_end  rows  platforms  positive_cases  prevalence
     train        2014      2019  8200       1607             538    0.065610
validation        2020      2021  1884        982              67    0.035563
      test        2022      2024  2196        876              94    0.042805

Leakage audit
-------------
Failures: 0
Data-quality flags: 1

Interpretation rule
-------------------
Full data are used only for neutral coverage description. Target associations,
correlations, missingness, and distribution decisions use training sequences only.
Validation and evaluation distributions are compared only after the protocol is frozen.
PSI and KS values are descriptive and must not be used for further model selection.