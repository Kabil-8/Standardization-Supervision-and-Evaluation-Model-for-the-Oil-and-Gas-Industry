# Archived BSEE cohort sensitivity audit

This package reconstructs membership and compares retained with excluded
platform histories using the archived full and model panels. It supports a
transparent sensitivity analysis of the existing pipeline.

It does **not** establish historically effective predictor dates, publication
latency, a year-t registry independent of subsequent production, or complete
zero-INC outcome observability. Therefore it does not resolve Priority 2 and
must not be described as prospective or independent validation evidence.
